# Daily Market Bottom Monitor (standalone)

Runs separately from the weekly **Stock Rover Macro Market Map** and existing
**9-Master-3Y-Reco4Tomo.py** stock signal engine. It never modifies their files.

## Install (Windows PowerShell)

```powershell
cd "C:\path\to\market_bottom_monitor"
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Run

```powershell
.\.venv\Scripts\python.exe market_bottom_monitor.py
```

Optional **stock sample breadth** (your own representative Ticker column CSV):

```powershell
.\.venv\Scripts\python.exe market_bottom_monitor.py --universe "C:\path\to\my_stock_universe.csv" --min-breadth 100
```

A six-symbol example CSV is included only to illustrate the format. It is **not** sufficient for the 100-stock breadth threshold.

## Outputs

Saved under `market_bottom_output/` (configurable with `--output`):
- `market_bottom_YYYY-MM-DD.md` human-readable summary
- `market_bottom_YYYY-MM-DD.csv` one-row machine-readable snapshot
- `market_bottom_YYYY-MM-DD.json` complete metrics, component scores, limitations
- `market_bottom_history.csv` de-duplicated daily history, usable for weekly review

Runs on latest completed US session (cutoff 4:30 PM Eastern). On weekends/holidays uses most recent SPY session. Run daily **after 4:30 PM Eastern**, allowing data feeds time to update.

## Scoring and caveats

Experimental 100-point score: 25 breadth, 20 credit, 20 price, 15 momentum,
10 volatility, 10 leadership. Components are simple boolean-rule averages.
If fewer than 75 weight points are available, classification is **INSUFFICIENT DATA**;
missing groups are not misrepresented as healthy. Scores are NOT probabilities.

- **Without a universe file**, coverage is at most 75%; even with no breadth, a score is only a provisional ETF/credit/volatility signal. A broad market breadth source is recommended before relying on it.
- A filtered buy-signal shortlist would produce **biased sample breadth**; use a stable, broader universe, and interpret it as sample breadth only.
- No genuine NYSE/Nasdaq daily new lows, advance/decline volume, VIX futures curve, earnings revisions, or market-wide percentage above MAs without additional licensed/official feeds.
- FRED spreads have release delays and revised history; today's latest observable spread is not necessarily synchronous with today's ETF close. This pipeline is for monitoring, **not** lookahead-safe historical backtesting.
- Yahoo prices can be delayed, revised, or missing. No report is generated if SPY fails. Missing other inputs are identified, not fabricated.
- HY OAS is in **percentage points**, not basis points (3.75 means 375 bps).
- A single high VIX reading signals stress, not a bottom; the prototype rewards **VIX falling** rather than spiking.

## Keep three workflows separate

1. **Daily Market Bottom Monitor:** this script and its own output directory.
2. **Weekly Macro Market Map:** keep Stock Rover export and weekly report unchanged; optionally import daily history as a separate supplementary sheet.
3. **Daily stock signal engine:** leave existing Python composite scoring and execution list unchanged. A future downstream risk gate can use this monitor's JSON without altering individual stock scores.

## Windows Task Scheduler

Create a task that runs at 5:30 PM Eastern on weekdays (or your local equivalent):
- Program: `C:\path\to\market_bottom_monitor\.venv\Scripts\python.exe`
- Arguments: `"C:\path\to\market_bottom_monitor\market_bottom_monitor.py" --universe "C:\path\to\my_stock_universe.csv"`
- Start in: `C:\path\to\market_bottom_monitor`

Monitor logs and rerun manually when Yahoo/FRED has temporary outages.
